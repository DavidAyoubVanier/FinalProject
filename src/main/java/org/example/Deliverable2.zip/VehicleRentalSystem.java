package org.example;

public class VehicleRentalSystem {
    // attributes


    public void addVehicle(Vehicle v) {
        // TODO adds a vehicle to a fleet
    }

    public void rentVehicle() {
        // TODO rents a vehicle and writes to the rental logs
    }

    public void returnVehicle() {
        // TODO returns a vehicle, checks availability and returns a message
    }

    public void saveFleetToFile() {
        // TODO writes information about the fleet to an external file
    }

    public void loadFleetFromFile() {
        // TODO reads and prints information about the fleet from a file
    }

    // getters
}
