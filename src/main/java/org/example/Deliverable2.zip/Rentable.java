package org.example;

public interface Rentable {
    boolean rent();
    boolean returnVehicle();
}
