package org.example;

public class RentalLog {
    // attributes


    // constructor


    // toString


    // setters, getters


    public long getDuration() {
        // TODO gives the time left for the rental, requires implementation of attributes
    }
}
